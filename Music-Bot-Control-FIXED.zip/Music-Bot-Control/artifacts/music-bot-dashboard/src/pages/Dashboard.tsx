import React, { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import {
  useGetBotStatus,
  useGetBotStats,
  useGetQueue,
  useGetHistory,
  usePlayTrack,
  useStopPlayback,
  useSkipTrack,
  usePausePlayback,
  useResumePlayback,
  useSetVolume,
  useClearQueue,
  useRemoveFromQueue,
  getGetBotStatusQueryKey,
  getGetQueueQueryKey,
  getGetBotStatsQueryKey,
  getGetHistoryQueryKey
} from "@workspace/api-client-react";
import {
  Play, Pause, Square, SkipForward, Volume2, ListMusic, Plus,
  Trash2, History, Radio, Server, Activity, Disc3
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";

const AudioWaveform = ({ isPlaying }: { isPlaying: boolean }) => (
  <div className="flex items-end gap-[2px] h-3 ml-1 mr-1">
    {[1, 2, 3, 4].map((i) => (
       <div
         key={i}
         className={cn("w-[2px] bg-primary rounded-t-sm", isPlaying ? "animate-wave" : "h-1")}
         style={{ animationDelay: `${i * 0.15}s` }}
       />
    ))}
  </div>
);

export default function Dashboard() {
  const queryClient = useQueryClient();

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetQueueQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetBotStatsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetHistoryQueryKey() });
  };

  const { data: status } = useGetBotStatus({
    query: { refetchInterval: 3000, queryKey: getGetBotStatusQueryKey() }
  });
  const { data: stats } = useGetBotStats({
    query: { refetchInterval: 3000, queryKey: getGetBotStatsQueryKey() }
  });
  const { data: queue } = useGetQueue({
    query: { refetchInterval: 3000, queryKey: getGetQueueQueryKey() }
  });
  const { data: history } = useGetHistory({
    query: { queryKey: getGetHistoryQueryKey() }
  });

  const play = usePlayTrack({ mutation: { onSuccess: invalidateAll } });
  const stop = useStopPlayback({ mutation: { onSuccess: invalidateAll } });
  const skip = useSkipTrack({ mutation: { onSuccess: invalidateAll } });
  const pause = usePausePlayback({ mutation: { onSuccess: invalidateAll } });
  const resume = useResumePlayback({ mutation: { onSuccess: invalidateAll } });
  const setVolume = useSetVolume({ mutation: { onSuccess: invalidateAll } });
  const clear = useClearQueue({ mutation: { onSuccess: invalidateAll } });
  const remove = useRemoveFromQueue({ mutation: { onSuccess: invalidateAll } });

  const form = useForm({
    defaultValues: { query: "", requestedBy: "", voiceChannelId: "" }
  });

  const onSubmit = form.handleSubmit((data) => {
    play.mutate({
      data: {
        query: data.query,
        requestedBy: data.requestedBy,
        ...(data.voiceChannelId ? { voiceChannelId: data.voiceChannelId } : {})
      }
    }, {
      onSuccess: () => form.resetField("query")
    });
  });

  const [sliderVol, setSliderVol] = useState(status?.volume || 50);

  useEffect(() => {
    if (status?.volume !== undefined) {
       setSliderVol(status.volume);
    }
  }, [status?.volume]);

  const isPlaying = !!(status?.playing && !status?.paused);
  const currentTrack = status?.currentTrack;

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-primary/30">
      {/* Top Stats Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-card border-b border-border shadow-sm z-10 gap-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className={cn(
              "w-3 h-3 rounded-full",
              status?.online ? "bg-green-500" : "bg-destructive",
              isPlaying && "animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.7)]"
            )} />
            <span className="font-mono text-sm tracking-wider">
              {status?.online ? 'ONLINE' : 'OFFLINE'}
            </span>
          </div>
          <div className="text-muted-foreground font-mono text-sm flex items-center gap-2 hidden sm:flex">
            <Server className="w-4 h-4" />
            {status?.guildName || 'Not connected'}
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-sm">
          <div className="flex flex-col items-end">
            <span className="text-muted-foreground text-[10px] uppercase tracking-widest">Total Played</span>
            <span className="text-primary font-bold">{stats?.totalPlayed || 0}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-muted-foreground text-[10px] uppercase tracking-widest">Today</span>
            <span className="text-primary font-bold">{stats?.todayPlayed || 0}</span>
          </div>
          <div className="flex flex-col items-end hidden sm:flex">
            <span className="text-muted-foreground text-[10px] uppercase tracking-widest">Queue</span>
            <span className="text-primary font-bold">{stats?.queueLength || 0}</span>
          </div>
        </div>
      </div>

      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-6 lg:p-8 space-y-8 flex flex-col">
        {/* Player Stage */}
        <Card className="p-6 md:p-8 flex flex-col md:flex-row gap-8 items-center bg-card/40 backdrop-blur-xl border-border/50 shadow-2xl relative overflow-hidden">
          {/* Background glow */}
          <div className="absolute inset-0 bg-primary/5 opacity-50 pointer-events-none mix-blend-screen" />

          {/* Album Art */}
          <div className="w-56 h-56 md:w-64 md:h-64 bg-secondary rounded-xl overflow-hidden shrink-0 shadow-[0_0_40px_rgba(0,0,0,0.5)] relative group z-10">
            {currentTrack?.thumbnail ? (
              <img src={currentTrack.thumbnail} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105" alt="Thumbnail" />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-secondary/50 text-muted-foreground">
                <Disc3 className={cn("w-20 h-20 mb-4 opacity-20", isPlaying && "animate-spin duration-[3000ms]")} />
                <span className="font-mono text-xs opacity-50">NO ARTWORK</span>
              </div>
            )}
            {isPlaying && (
              <div className="absolute inset-0 ring-1 ring-primary/50 inset-ring rounded-xl pointer-events-none" />
            )}
          </div>

          {/* Player Info & Controls */}
          <div className="flex-1 w-full flex flex-col justify-center z-10">
            <div className="mb-8">
              <div className="flex flex-wrap items-center gap-3 mb-3">
                {isPlaying ? (
                  <span className="px-2.5 py-1 rounded bg-primary/20 border border-primary/30 text-primary text-[10px] font-mono font-bold tracking-widest flex items-center gap-1">
                    <AudioWaveform isPlaying={isPlaying} /> NOW PLAYING
                  </span>
                ) : status?.paused ? (
                   <span className="px-2.5 py-1 rounded bg-amber-500/20 border border-amber-500/30 text-amber-500 text-[10px] font-mono font-bold tracking-widest flex items-center gap-2">
                     PAUSED
                   </span>
                ) : (
                   <span className="px-2.5 py-1 rounded bg-secondary text-muted-foreground text-[10px] font-mono font-bold tracking-widest">
                     IDLE
                   </span>
                )}
                {status?.voiceChannel && (
                  <span className="text-muted-foreground text-xs font-mono flex items-center gap-1">
                    <Radio className="w-3 h-3" /> {status.voiceChannel}
                  </span>
                )}
              </div>

              <h2 className="text-3xl md:text-4xl font-bold line-clamp-2 leading-tight tracking-tight mb-2">
                {currentTrack?.title || 'Silence.'}
              </h2>

              {currentTrack && (
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <p>
                    Req by <span className="text-foreground font-medium">{currentTrack.requestedBy}</span>
                  </p>
                  {currentTrack.duration && (
                    <>
                      <span className="opacity-30">•</span>
                      <span className="font-mono">{currentTrack.duration}</span>
                    </>
                  )}
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between w-full gap-6 bg-secondary/20 p-4 rounded-xl border border-border/30">
              <div className="flex items-center gap-3">
                 <Button
                   variant="outline"
                   size="icon"
                   className="w-14 h-14 rounded-full border-border/50 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all shadow-lg hover:shadow-primary/25"
                   onClick={() => status?.paused ? resume.mutate({}) : pause.mutate({})}
                   disabled={!currentTrack || pause.isPending || resume.isPending}
                 >
                   {status?.paused ? <Play className="w-6 h-6 ml-1" /> : <Pause className="w-6 h-6" />}
                 </Button>
                 <Button
                   variant="ghost"
                   size="icon"
                   className="w-12 h-12 rounded-full hover:bg-secondary"
                   onClick={() => stop.mutate({})}
                   disabled={!currentTrack || stop.isPending}
                 >
                   <Square className="w-5 h-5" />
                 </Button>
                 <Button
                   variant="ghost"
                   size="icon"
                   className="w-12 h-12 rounded-full hover:bg-secondary"
                   onClick={() => skip.mutate({})}
                   disabled={!currentTrack || skip.isPending}
                 >
                   <SkipForward className="w-5 h-5" />
                 </Button>
              </div>

              <div className="flex items-center gap-4 w-full sm:w-56">
                <Volume2 className={cn("w-4 h-4 shrink-0 transition-colors", sliderVol > 0 ? "text-primary" : "text-muted-foreground")} />
                <Slider
                  value={[sliderVol]}
                  max={100}
                  step={1}
                  onValueChange={(val) => setSliderVol(val[0])}
                  onValueCommit={(val) => setVolume.mutate({ data: { volume: val[0] } })}
                  className="flex-1"
                />
                <span className="font-mono text-xs w-8 text-right text-muted-foreground">{sliderVol}%</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Bottom Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          {/* Left Column: Queue & History */}
          <div className="lg:col-span-2">
             <Tabs defaultValue="queue" className="w-full">
               <TabsList className="mb-6 bg-card border border-border/50">
                 <TabsTrigger value="queue" className="font-mono text-xs uppercase tracking-widest px-6">Queue</TabsTrigger>
                 <TabsTrigger value="history" className="font-mono text-xs uppercase tracking-widest px-6">History</TabsTrigger>
               </TabsList>

               <TabsContent value="queue" className="space-y-4 outline-none">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-mono text-sm text-muted-foreground flex items-center gap-2">
                      <ListMusic className="w-4 h-4" /> UP NEXT <span className="text-foreground bg-secondary px-2 py-0.5 rounded-full">{queue?.length || 0}</span>
                    </h3>
                    {queue && queue.length > 0 && (
                      <Button variant="ghost" size="sm" className="h-8 text-xs text-destructive hover:text-destructive hover:bg-destructive/10 font-mono uppercase" onClick={() => clear.mutate({})}>
                        Clear All
                      </Button>
                    )}
                  </div>

                  {(!queue || queue.length === 0) ? (
                    <div className="text-center py-16 text-muted-foreground font-mono text-sm bg-card/30 rounded-xl border border-border/50 border-dashed flex flex-col items-center gap-3">
                      <ListMusic className="w-8 h-8 opacity-20" />
                      Queue is currently empty
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {queue.map((track, i) => (
                        <div key={track.id} className="flex items-center gap-4 p-3 pr-4 bg-card/40 rounded-lg hover:bg-card/80 transition-colors group border border-border/30 hover:border-border">
                          <span className="w-8 text-center font-mono text-muted-foreground text-xs">{i + 1}</span>
                          {track.thumbnail ? (
                            <img src={track.thumbnail} className="w-12 h-12 rounded object-cover shadow-sm" alt="" />
                          ) : (
                            <div className="w-12 h-12 rounded bg-secondary flex items-center justify-center"><ListMusic className="w-4 h-4 text-muted-foreground"/></div>
                          )}
                          <div className="flex-1 min-w-0">
                             <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{track.title}</p>
                             <p className="text-xs text-muted-foreground truncate mt-1">Req by <span className="text-foreground/70">{track.requestedBy}</span> {track.duration && `• ${track.duration}`}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="opacity-0 group-hover:opacity-100 text-destructive hover:text-destructive hover:bg-destructive/20 h-8 w-8 rounded-full"
                            onClick={() => remove.mutate({ position: track.position })}
                          >
                             <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
               </TabsContent>

               <TabsContent value="history" className="space-y-4 outline-none">
                 <div className="flex items-center justify-between mb-4">
                    <h3 className="font-mono text-sm text-muted-foreground flex items-center gap-2">
                      <History className="w-4 h-4" /> RECENTLY PLAYED
                    </h3>
                  </div>
                  {(!history || history.length === 0) ? (
                     <div className="text-center py-16 text-muted-foreground font-mono text-sm bg-card/30 rounded-xl border border-border/50 border-dashed flex flex-col items-center gap-3">
                       <History className="w-8 h-8 opacity-20" />
                       No play history
                     </div>
                  ) : (
                     <div className="space-y-2">
                       {history.map((track) => (
                         <div key={track.id} className="flex items-center gap-4 p-3 bg-card/20 rounded-lg border border-transparent">
                           {track.thumbnail ? (
                            <img src={track.thumbnail} className="w-10 h-10 rounded object-cover opacity-50 grayscale" alt="" />
                          ) : (
                            <div className="w-10 h-10 rounded bg-secondary/50 flex items-center justify-center opacity-60"><ListMusic className="w-4 h-4 text-muted-foreground"/></div>
                          )}
                          <div className="flex-1 min-w-0">
                             <p className="text-sm font-medium truncate text-muted-foreground">{track.title}</p>
                             <p className="text-xs text-muted-foreground/50 truncate mt-0.5">Req by {track.requestedBy} • {new Date(track.playedAt).toLocaleTimeString()}</p>
                          </div>
                         </div>
                       ))}
                     </div>
                  )}
               </TabsContent>
             </Tabs>
          </div>

          {/* Right Column: Add Song Form */}
          <div className="lg:col-span-1 sticky top-6">
             <Card className="p-6 bg-card/60 backdrop-blur border-border/50">
               <h3 className="font-mono text-sm font-bold mb-6 flex items-center gap-2 tracking-widest text-primary">
                 <Plus className="w-4 h-4"/> ADD TRACK
               </h3>
               <form onSubmit={onSubmit} className="space-y-5">
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase font-mono tracking-widest text-muted-foreground">Search or YouTube URL</Label>
                    <Input
                      placeholder="Rick Astley..."
                      className="bg-background/50 font-mono text-sm border-border/50 focus-visible:ring-primary h-11"
                      {...form.register("query", { required: true })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase font-mono tracking-widest text-muted-foreground">Requested By</Label>
                    <Input
                      placeholder="DJ Name"
                      className="bg-background/50 font-mono text-sm border-border/50 focus-visible:ring-primary h-11"
                      {...form.register("requestedBy", { required: true })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] uppercase font-mono tracking-widest text-muted-foreground">Voice Channel ID (Optional)</Label>
                    <Input
                      placeholder="123456789..."
                      className="bg-background/50 font-mono text-sm border-border/50 focus-visible:ring-primary h-11"
                      {...form.register("voiceChannelId")}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full h-12 font-mono uppercase tracking-widest text-xs hover:shadow-[0_0_15px_rgba(var(--primary),0.5)] transition-all"
                    disabled={play.isPending}
                  >
                    {play.isPending ? 'Queuing...' : 'Add to Queue'}
                  </Button>
               </form>
             </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
