import { Router } from "express";
import { db, queueTable, historyTable } from "@workspace/db";
import { eq, asc, desc, count, gte, lt, and } from "drizzle-orm";
import {
  addToQueue,
  stopPlayback,
  pausePlayback,
  resumePlayback,
  setVolume,
  skipTrack,
  getPlayerState,
  searchAndResolve,
  getVoiceChannelName,
  getCurrentGuildName,
} from "../bot";
import { getDiscordClient, getUptimeSeconds } from "../bot";

const router = Router();

// GET /api/bot/status
router.get("/status", async (req, res) => {
  try {
    const client = getDiscordClient();
    const online = client.isReady();
    const state = getPlayerState();

    let currentTrack = null;
    if (state.currentTrackId !== null) {
      const tracks = await db
        .select()
        .from(queueTable)
        .where(eq(queueTable.id, state.currentTrackId))
        .limit(1);
      if (tracks.length > 0) {
        const t = tracks[0]!;
        currentTrack = {
          id: t.id,
          title: t.title,
          url: t.url,
          thumbnail: t.thumbnail,
          duration: t.duration,
          requestedBy: t.requestedBy,
          position: t.position,
          addedAt: t.addedAt.toISOString(),
        };
      }
    }

    res.json({
      online,
      playing: state.playing,
      paused: state.paused,
      volume: state.volume,
      voiceChannel: getVoiceChannelName(),
      guildName: getCurrentGuildName(),
      currentTrack,
    });
  } catch (err) {
    req.log.error({ err }, "Error getting bot status");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/bot/stats
router.get("/stats", async (req, res) => {
  try {
    const [totalResult] = await db.select({ c: count() }).from(historyTable);
    const queueResult = await db.select({ c: count() }).from(queueTable);

    // Today's count
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const [todayResult] = await db
      .select({ c: count() })
      .from(historyTable)
      .where(and(gte(historyTable.playedAt, today), lt(historyTable.playedAt, tomorrow)));
    const todayPlayed = todayResult?.c ?? 0;

    res.json({
      totalPlayed: totalResult?.c ?? 0,
      todayPlayed,
      uptimeSeconds: getUptimeSeconds(),
      queueLength: queueResult[0]?.c ?? 0,
    });
  } catch (err) {
    req.log.error({ err }, "Error getting bot stats");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/bot/play
router.post("/play", async (req, res) => {
  try {
    const { query, requestedBy, voiceChannelId } = req.body as {
      query: string;
      requestedBy: string;
      voiceChannelId?: string;
    };

    if (!query || !requestedBy) {
      res.status(400).json({ error: "query and requestedBy are required" });
      return;
    }

    const info = await searchAndResolve(query);
    const track = await addToQueue(
      info.url,
      info.title,
      info.thumbnail,
      info.duration,
      requestedBy,
      voiceChannelId,
    );

    res.json({
      id: track.id,
      title: track.title,
      url: track.url,
      thumbnail: track.thumbnail,
      duration: track.duration,
      requestedBy: track.requestedBy,
      position: track.position,
      addedAt: track.addedAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Error playing track");
    res.status(400).json({ error: String(err) });
  }
});

// POST /api/bot/stop
router.post("/stop", async (req, res) => {
  try {
    await db.delete(queueTable);
    stopPlayback();
    res.json({ success: true, message: "Playback stopped and queue cleared" });
  } catch (err) {
    req.log.error({ err }, "Error stopping playback");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/bot/skip
router.post("/skip", async (req, res) => {
  try {
    await skipTrack();
    res.json({ success: true, message: "Skipped to next track" });
  } catch (err) {
    req.log.error({ err }, "Error skipping track");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/bot/pause
router.post("/pause", async (req, res) => {
  try {
    const result = pausePlayback();
    res.json({
      success: result,
      message: result ? "Paused" : "Nothing to pause",
    });
  } catch (err) {
    req.log.error({ err }, "Error pausing playback");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/bot/resume
router.post("/resume", async (req, res) => {
  try {
    const result = resumePlayback();
    res.json({
      success: result,
      message: result ? "Resumed" : "Nothing to resume",
    });
  } catch (err) {
    req.log.error({ err }, "Error resuming playback");
    res.status(500).json({ error: "Internal server error" });
  }
});

// PATCH /api/bot/volume
router.patch("/volume", async (req, res) => {
  try {
    const { volume } = req.body as { volume: number };
    if (typeof volume !== "number" || volume < 0 || volume > 100) {
      res.status(400).json({ error: "volume must be 0-100" });
      return;
    }
    setVolume(volume);
    res.json({ success: true, message: `Volume set to ${volume}` });
  } catch (err) {
    req.log.error({ err }, "Error setting volume");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/bot/queue
router.get("/queue", async (req, res) => {
  try {
    const items = await db
      .select()
      .from(queueTable)
      .orderBy(asc(queueTable.position));
    res.json(
      items.map((t) => ({
        id: t.id,
        title: t.title,
        url: t.url,
        thumbnail: t.thumbnail,
        duration: t.duration,
        requestedBy: t.requestedBy,
        position: t.position,
        addedAt: t.addedAt.toISOString(),
      })),
    );
  } catch (err) {
    req.log.error({ err }, "Error getting queue");
    res.status(500).json({ error: "Internal server error" });
  }
});

// DELETE /api/bot/queue (clear all)
router.delete("/queue", async (req, res) => {
  try {
    await db.delete(queueTable);
    res.json({ success: true, message: "Queue cleared" });
  } catch (err) {
    req.log.error({ err }, "Error clearing queue");
    res.status(500).json({ error: "Internal server error" });
  }
});

// DELETE /api/bot/queue/:position
router.delete("/queue/:position", async (req, res) => {
  try {
    const position = parseInt(req.params["position"]!, 10);
    if (isNaN(position)) {
      res.status(400).json({ error: "Invalid position" });
      return;
    }

    const items = await db
      .select()
      .from(queueTable)
      .where(eq(queueTable.position, position));

    if (items.length === 0) {
      res.status(404).json({ error: "No track at that position" });
      return;
    }

    await db.delete(queueTable).where(eq(queueTable.id, items[0]!.id));

    // Re-number remaining
    const remaining = await db
      .select()
      .from(queueTable)
      .orderBy(asc(queueTable.position));
    for (let i = 0; i < remaining.length; i++) {
      await db
        .update(queueTable)
        .set({ position: i + 1 })
        .where(eq(queueTable.id, remaining[i]!.id));
    }

    res.json({ success: true, message: "Track removed from queue" });
  } catch (err) {
    req.log.error({ err }, "Error removing from queue");
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET /api/bot/history
router.get("/history", async (req, res) => {
  try {
    const items = await db
      .select()
      .from(historyTable)
      .orderBy(desc(historyTable.playedAt))
      .limit(50);
    res.json(
      items.map((t) => ({
        id: t.id,
        title: t.title,
        url: t.url,
        thumbnail: t.thumbnail,
        duration: t.duration,
        requestedBy: t.requestedBy,
        playedAt: t.playedAt.toISOString(),
      })),
    );
  } catch (err) {
    req.log.error({ err }, "Error getting history");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
