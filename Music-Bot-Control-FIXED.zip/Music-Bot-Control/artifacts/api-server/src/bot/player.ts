import {
  createAudioPlayer,
  createAudioResource,
  joinVoiceChannel,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  type VoiceConnection,
  type AudioPlayer,
  type AudioResource,
} from "@discordjs/voice";
import play from "play-dl";
import { db, queueTable, historyTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { getDiscordClient } from "./client";
import type { Guild } from "discord.js";
import { logger } from "../lib/logger";

interface PlayerState {
  playing: boolean;
  paused: boolean;
  volume: number;
  voiceChannelId: string | null;
  guildId: string | null;
  currentTrackId: number | null;
}

const state: PlayerState = {
  playing: false,
  paused: false,
  volume: 80,
  voiceChannelId: null,
  guildId: null,
  currentTrackId: null,
};

let audioPlayer: AudioPlayer | null = null;
let voiceConnection: VoiceConnection | null = null;
let currentResource: AudioResource | null = null;
let suppressIdle = false;
let advancing = false;

function getOrCreatePlayer(): AudioPlayer {
  if (!audioPlayer) {
    audioPlayer = createAudioPlayer();
    audioPlayer.on(AudioPlayerStatus.Idle, () => {
      if (suppressIdle) {
        suppressIdle = false;
        return;
      }
      void advanceQueue();
    });
    audioPlayer.on("error", (err) => {
      logger.error({ err }, "Audio player error");
      void advanceQueue();
    });
  }
  return audioPlayer;
}

async function moveCurrentToHistory(trackId: number): Promise<void> {
  const [track] = await db.select().from(queueTable).where(eq(queueTable.id, trackId)).limit(1);
  if (!track) return;
  await db.insert(historyTable).values({
    title: track.title,
    url: track.url,
    thumbnail: track.thumbnail,
    duration: track.duration,
    requestedBy: track.requestedBy,
  });
  await db.delete(queueTable).where(eq(queueTable.id, trackId));
}

async function reorderQueue(): Promise<void> {
  const items = await db.select().from(queueTable).orderBy(asc(queueTable.position));
  for (let i = 0; i < items.length; i++) {
    await db.update(queueTable).set({ position: i + 1 }).where(eq(queueTable.id, items[i]!.id));
  }
}

async function advanceQueue(): Promise<void> {
  if (advancing) return;
  advancing = true;
  try {
    const finishedId = state.currentTrackId;
    state.currentTrackId = null;
    state.playing = false;
    state.paused = false;
    currentResource = null;
    if (finishedId !== null) await moveCurrentToHistory(finishedId);
    await reorderQueue();
    await playNextTrack();
  } catch (err) {
    logger.error({ err }, "Could not advance music queue");
  } finally {
    advancing = false;
  }
}

export async function playNextTrack(): Promise<void> {
  if (state.playing || state.paused) return;
  if (!voiceConnection || voiceConnection.state.status !== VoiceConnectionStatus.Ready) {
    logger.warn("Cannot play: bot is not connected to a ready voice channel");
    return;
  }
  const [track] = await db.select().from(queueTable).orderBy(asc(queueTable.position)).limit(1);
  if (!track) {
    state.playing = false;
    state.paused = false;
    state.currentTrackId = null;
    return;
  }
  try {
    const streamResult = await play.stream(track.url, { quality: 2 });
    const resource = createAudioResource(streamResult.stream, {
      inputType: streamResult.type as any,
      inlineVolume: true,
    });
    resource.volume?.setVolume(state.volume / 100);
    currentResource = resource;
    const player = getOrCreatePlayer();
    voiceConnection.subscribe(player);
    state.currentTrackId = track.id;
    state.playing = true;
    state.paused = false;
    player.play(resource);
    logger.info({ title: track.title }, "Now playing");
  } catch (err) {
    logger.error({ err, title: track.title }, "Failed to stream track; skipping it");
    await moveCurrentToHistory(track.id);
    await reorderQueue();
    state.currentTrackId = null;
    state.playing = false;
    await playNextTrack();
  }
}

export async function joinChannel(voiceChannelId: string): Promise<void> {
  const client = getDiscordClient();
  if (!client.isReady()) throw new Error("البوت غير متصل بديسكورد بعد");
  let targetGuild: Guild | null = null;
  for (const guild of client.guilds.cache.values()) {
    const channel = guild.channels.cache.get(voiceChannelId);
    if (channel?.isVoiceBased()) {
      targetGuild = guild;
      break;
    }
  }
  if (!targetGuild) {
    throw new Error("لم أستطع العثور على الروم الصوتي أو أن البوت لا يملك صلاحية الوصول إليه");
  }
  if (voiceConnection && state.voiceChannelId === voiceChannelId && voiceConnection.state.status === VoiceConnectionStatus.Ready) return;
  voiceConnection?.destroy();
  voiceConnection = joinVoiceChannel({
    channelId: voiceChannelId,
    guildId: targetGuild.id,
    adapterCreator: targetGuild.voiceAdapterCreator,
    selfDeaf: true,
  });
  try {
    await entersState(voiceConnection, VoiceConnectionStatus.Ready, 15_000);
    state.voiceChannelId = voiceChannelId;
    state.guildId = targetGuild.id;
    logger.info({ voiceChannelId, guildId: targetGuild.id }, "Joined voice channel");
  } catch (err) {
    voiceConnection.destroy();
    voiceConnection = null;
    state.voiceChannelId = null;
    state.guildId = null;
    throw new Error("فشل دخول الروم الصوتي؛ تأكد من صلاحيات Connect وSpeak");
  }
  if (audioPlayer) voiceConnection.subscribe(audioPlayer);
}

export async function addToQueue(
  url: string,
  title: string,
  thumbnail: string | null,
  duration: string | null,
  requestedBy: string,
  voiceChannelId?: string,
): Promise<typeof queueTable.$inferSelect> {
  if (voiceChannelId) await joinChannel(voiceChannelId);
  if (!voiceConnection || voiceConnection.state.status !== VoiceConnectionStatus.Ready) {
    throw new Error("لازم البوت يدخل روم صوتي قبل تشغيل الأغاني");
  }
  const existing = await db.select().from(queueTable).orderBy(asc(queueTable.position));
  const [inserted] = await db.insert(queueTable).values({
    title, url, thumbnail, duration, requestedBy, position: existing.length + 1,
  }).returning();
  if (!inserted) throw new Error("Failed to insert into queue");
  if (!state.playing && !state.paused) await playNextTrack();
  return inserted;
}

export function stopPlayback(): void {
  suppressIdle = !!audioPlayer && audioPlayer.state.status !== AudioPlayerStatus.Idle;
  state.playing = false;
  state.paused = false;
  state.currentTrackId = null;
  currentResource = null;
  if (audioPlayer) audioPlayer.stop(true);
  if (voiceConnection) {
    voiceConnection.destroy();
    voiceConnection = null;
  }
  state.voiceChannelId = null;
  state.guildId = null;
}

export function pausePlayback(): boolean {
  if (audioPlayer && state.playing && !state.paused) {
    const paused = audioPlayer.pause();
    if (paused) state.paused = true;
    return paused;
  }
  return false;
}

export function resumePlayback(): boolean {
  if (audioPlayer && state.paused) {
    const resumed = audioPlayer.unpause();
    if (resumed) state.paused = false;
    return resumed;
  }
  return false;
}

export function setVolume(volume: number): void {
  state.volume = Math.max(0, Math.min(100, Math.round(volume)));
  currentResource?.volume?.setVolume(state.volume / 100);
}

export function getPlayerState(): PlayerState { return { ...state }; }

export async function skipTrack(): Promise<void> {
  if (state.currentTrackId === null) return;
  // Stop causes Idle; that event performs the history update and queue advance.
  if (audioPlayer) audioPlayer.stop(true);
}

export async function searchAndResolve(query: string): Promise<{ url: string; title: string; thumbnail: string | null; duration: string | null }> {
  const trimmed = query.trim();
  if (!trimmed) throw new Error("اكتب اسم الأغنية أو رابط YouTube");
  const isUrl = /^https?:\/\//i.test(trimmed);
  if (isUrl) {
    const info = await play.video_info(trimmed);
    const details = info.video_details;
    return { url: trimmed, title: details.title || "Unknown", thumbnail: details.thumbnails?.[0]?.url || null, duration: details.durationRaw || null };
  }
  const results = await play.search(trimmed, { limit: 1 });
  const video = results?.[0];
  if (!video?.url) throw new Error("لم يتم العثور على نتائج للأغنية");
  return { url: video.url, title: video.title || "Unknown", thumbnail: video.thumbnails?.[0]?.url || null, duration: video.durationRaw || null };
}

export function getVoiceChannelName(): string | null {
  if (!state.voiceChannelId) return null;
  const client = getDiscordClient();
  for (const guild of client.guilds.cache.values()) {
    const channel = guild.channels.cache.get(state.voiceChannelId);
    if (channel) return channel.name;
  }
  return state.voiceChannelId;
}
export function getCurrentGuildName(): string | null {
  if (!state.guildId) return null;
  return getDiscordClient().guilds.cache.get(state.guildId)?.name || null;
}
