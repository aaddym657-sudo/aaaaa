import {
  Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  type ChatInputCommandInteraction, type Message,
} from "discord.js";
import { logger } from "../lib/logger";
import { addToQueue, searchAndResolve, getPlayerState, pausePlayback, resumePlayback, skipTrack, stopPlayback, setVolume } from "./player";

let client: Client | null = null;
let handlersRegistered = false;
const startTime = Date.now();
const PREFIX = process.env["COMMAND_PREFIX"] || "!";

export function getDiscordClient(): Client {
  if (!client) {
    client = new Client({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
    });
  }
  return client;
}
export function getUptimeSeconds(): number { return Math.floor((Date.now() - startTime) / 1000); }

function isAllowedContext(guildId: string, channelId: string): boolean {
  const configuredGuild = process.env["GUILD_ID"] || process.env["SERVER_ID"];
  const configuredChannel = process.env["CHANNEL_ID"];
  return (!configuredGuild || configuredGuild === guildId) && (!configuredChannel || configuredChannel === channelId);
}

async function queueSong(query: string, requestedBy: string, voiceChannelId: string) {
  const info = await searchAndResolve(query);
  const track = await addToQueue(info.url, info.title, info.thumbnail, info.duration, requestedBy, voiceChannelId);
  return { info, track };
}

function playerControls() {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("music:pause").setLabel("إيقاف مؤقت").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("music:skip").setLabel("تخطي").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("music:vol_down").setLabel("🔉").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("music:vol_up").setLabel("🔊").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("music:stop").setLabel("إيقاف البوت").setStyle(ButtonStyle.Danger),
  );
}

async function sendNowPlaying(target: { reply: (options: any) => Promise<any> }, info: { title: string; url: string; thumbnail: string | null; duration: string | null }, requester: string) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("🎵 جاري التشغيل")
    .setDescription(`[${info.title}](${info.url})`)
    .addFields({ name: "المدة", value: info.duration || "غير معروف", inline: true }, { name: "طلب بواسطة", value: requester, inline: true });
  if (info.thumbnail) embed.setThumbnail(info.thumbnail);
  return target.reply({ embeds: [embed], components: [playerControls()] });
}

async function handleMessage(message: Message): Promise<void> {
  if (message.author.bot || !message.guild || !isAllowedContext(message.guild.id, message.channelId)) return;
  const content = message.content.trim();
  const escapedPrefix = PREFIX.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = content.match(new RegExp(`^(?:${escapedPrefix}|/)(?:play|تشغيل)\\s+(.+)$`, "i"));
  const arabicMatch = content.match(/^تشغيل\s+(.+)$/i);
  if (!match && !arabicMatch) return;
  const query = (match?.[1] || arabicMatch?.[1] || "").trim();
  const voiceChannelId = message.member?.voice.channelId;
  if (!voiceChannelId) {
    await message.reply("ادخل روم صوتي الأول، وبعدها اطلب الأغنية هنا.");
    return;
  }
  try {
    await message.channel.sendTyping();
    const { info } = await queueSong(query, message.author.username, voiceChannelId);
    await sendNowPlaying({ reply: (options) => message.reply(options) }, info, message.author.username);
  } catch (err) {
    logger.error({ err }, "Message play command failed");
    await message.reply(`❌ ${err instanceof Error ? err.message : "حصل خطأ أثناء تشغيل الأغنية"}`);
  }
}

async function handleSlash(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!interaction.guild || !isAllowedContext(interaction.guild.id, interaction.channelId || "")) {
    await interaction.reply({ content: "الأمر غير مسموح في السيرفر أو القناة دي.", ephemeral: true });
    return;
  }
  if (interaction.commandName !== "play") return;
  const invokingMember = await interaction.guild.members.fetch(interaction.user.id);
  const memberVoice = invokingMember.voice.channelId;
  if (!memberVoice) {
    await interaction.reply({ content: "ادخل روم صوتي الأول، وبعدها اطلب الأغنية.", ephemeral: true });
    return;
  }
  const query = interaction.options.getString("query", true);
  await interaction.deferReply();
  try {
    const { info } = await queueSong(query, interaction.user.username, memberVoice);
    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle("🎵 جاري التشغيل").setDescription(`[${info.title}](${info.url})`);
    if (info.thumbnail) embed.setThumbnail(info.thumbnail);
    await interaction.editReply({ embeds: [embed], components: [playerControls()] });
  } catch (err) {
    await interaction.editReply(`❌ ${err instanceof Error ? err.message : "حصل خطأ أثناء تشغيل الأغنية"}`);
  }
}

async function registerSlashCommands(token: string): Promise<void> {
  const guildId = process.env["GUILD_ID"] || process.env["SERVER_ID"];
  const applicationId = process.env["CLIENT_ID"];
  if (!guildId || !applicationId) {
    logger.warn("Slash commands not registered: set GUILD_ID and CLIENT_ID (application ID)");
    return;
  }
  const commands = [new SlashCommandBuilder().setName("play").setDescription("تشغيل أغنية من YouTube").addStringOption(option => option.setName("query").setDescription("اسم الأغنية أو رابط YouTube").setRequired(true)).toJSON()];
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationGuildCommands(applicationId, guildId), { body: commands });
  logger.info("Discord slash commands registered");
}

function registerHandlers(c: Client): void {
  if (handlersRegistered) return;
  handlersRegistered = true;
  c.on("messageCreate", (message) => { void handleMessage(message); });
  c.on("interactionCreate", async (interaction) => {
    if (interaction.isChatInputCommand()) { await handleSlash(interaction); return; }
    if (!interaction.isButton() || !interaction.customId.startsWith("music:")) return;
    const action = interaction.customId.slice(6);
    const current = getPlayerState();
    try {
      if (action === "pause") {
        const changed = current.paused ? resumePlayback() : pausePlayback();
        await interaction.reply({ content: changed ? (current.paused ? "تم استكمال التشغيل" : "تم الإيقاف المؤقت") : "لا توجد أغنية للتحكم بها", ephemeral: true });
      } else if (action === "skip") {
        await skipTrack();
        await interaction.reply({ content: "تم تخطي الأغنية", ephemeral: true });
      } else if (action === "stop") {
        const { db, queueTable } = await import("@workspace/db");
        await db.delete(queueTable);
        stopPlayback();
        await interaction.reply({ content: "تم إيقاف التشغيل ومسح قائمة الانتظار", ephemeral: true });
      } else if (action === "vol_down" || action === "vol_up") {
        const volume = Math.max(0, Math.min(100, current.volume + (action === "vol_up" ? 10 : -10)));
        setVolume(volume);
        await interaction.reply({ content: `مستوى الصوت: ${volume}%`, ephemeral: true });
      }
    } catch (err) {
      logger.error({ err }, "Music button failed");
      if (interaction.deferred || interaction.replied) await interaction.followUp({ content: "تعذر تنفيذ الأمر", ephemeral: true });
      else await interaction.reply({ content: "تعذر تنفيذ الأمر", ephemeral: true });
    }
  });
}

export async function connectBot(): Promise<void> {
  const token = process.env["DISCORD_TOKEN"];
  if (!token) {
    logger.warn("DISCORD_TOKEN not set — bot will not connect to Discord");
    return;
  }
  const c = getDiscordClient();
  registerHandlers(c);
  c.once("ready", () => logger.info({ tag: c.user?.tag }, "Discord bot connected"));
  c.on("error", (err) => logger.error({ err }, "Discord client error"));
  try {
    await c.login(token);
    await registerSlashCommands(token).catch((err) => logger.error({ err }, "Could not register slash commands"));
  } catch (err) {
    logger.error({ err }, "Failed to login to Discord");
    throw err;
  }
}
