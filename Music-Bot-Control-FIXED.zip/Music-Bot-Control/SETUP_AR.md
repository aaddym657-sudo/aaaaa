# إعداد Music Bot (بالعربي)

## 1) المتطلبات
- Node.js 20 أو أحدث.
- pnpm.
- PostgreSQL وقاعدة بيانات متاحة.
- بوت Discord من Discord Developer Portal.

## 2) الإعدادات
انسخ `.env.example` إلى `.env` واملأ القيم:
- `DISCORD_TOKEN`: توكن البوت. لا تشاركه مع أي شخص ولا ترفعه إلى GitHub.
- `GUILD_ID`: ID السيرفر.
- `CHANNEL_ID`: ID قناة الكتابة التي يستقبل فيها البوت الأوامر.
- `CLIENT_ID`: Application ID الموجود في صفحة General Information.
- `DATABASE_URL`: رابط PostgreSQL.
- `PORT`: منفذ تشغيل السيرفر.

## 3) صلاحيات البوت
من Discord Developer Portal فعّل **Message Content Intent** من صفحة Bot.
أضف البوت للسيرفر بصلاحيات:
- View Channels
- Send Messages
- Embed Links
- Read Message History
- Connect
- Speak
- Use Application Commands

تأكد أن البوت يستطيع رؤية قناة الكتابة المحددة والروم الصوتي.

## 4) التثبيت والتشغيل
من مجلد المشروع:
```bash
pnpm install
pnpm run build
```
ثم شغّل API server من بيئة المشروع بالطريقة المعتمدة فيها. داخل Replit عادةً استخدم أمر التشغيل المحدد في `.replit`.

## 5) الأوامر
في قناة الكتابة المحددة:
- `!play اسم الأغنية`
- `!تشغيل اسم الأغنية`
- `تشغيل اسم الأغنية`
- `/play` ثم اكتب اسم الأغنية في خانة `query`.

يجب أن يكون الشخص الذي يطلب الأغنية داخل روم صوتي. البوت يدخل نفس الروم تلقائيًا.

## 6) ملاحظات مهمة
- أوامر Slash يتم تسجيلها في السيرفر المحدد عند تشغيل البوت، بشرط صحة `GUILD_ID` و`CLIENT_ID`.
- لو غيّرت التوكن، غيّره من Secrets/Environment Variables وليس داخل الكود.
- لا تضع ملف `.env` الحقيقي داخل ملف ZIP عند مشاركة المشروع.
- تشغيل YouTube يعتمد على خدمة YouTube ومكتبة `play-dl`؛ قد تتغير إمكانية البث إذا غيّرت YouTube سياساتها أو آلياتها.
- لوحة التحكم تحتاج قاعدة البيانات والـ API server شغالين. لا تعتبر ظهور الواجهة وحده دليلًا على اتصال البوت.

## 7) إنشاء جداول قاعدة البيانات لأول مرة
بعد إنشاء قاعدة PostgreSQL، نفّذ محتوى `database/schema.sql` مرة واحدة على قاعدة البيانات (من أداة SQL في مزود PostgreSQL أو باستخدام `psql`). من دون هذه الجداول سيعمل السيرفر لكن طلبات قائمة التشغيل والإحصائيات ستفشل.
