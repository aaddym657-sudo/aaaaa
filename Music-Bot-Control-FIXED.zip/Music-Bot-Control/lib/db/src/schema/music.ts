import { pgTable, serial, text, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const queueTable = pgTable("queue", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  thumbnail: text("thumbnail"),
  duration: text("duration"),
  requestedBy: text("requested_by").notNull(),
  position: integer("position").notNull().default(0),
  addedAt: timestamp("added_at").defaultNow().notNull(),
});

export const historyTable = pgTable("history", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  thumbnail: text("thumbnail"),
  duration: text("duration"),
  requestedBy: text("requested_by").notNull(),
  playedAt: timestamp("played_at").defaultNow().notNull(),
});

export const botSettingsTable = pgTable("bot_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
});

export const insertQueueSchema = createInsertSchema(queueTable).omit({ id: true, addedAt: true });
export const insertHistorySchema = createInsertSchema(historyTable).omit({ id: true, playedAt: true });

export type QueueItem = typeof queueTable.$inferSelect;
export type InsertQueueItem = z.infer<typeof insertQueueSchema>;
export type HistoryItem = typeof historyTable.$inferSelect;
export type InsertHistoryItem = z.infer<typeof insertHistorySchema>;
export type BotSetting = typeof botSettingsTable.$inferSelect;
